﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace SwipeViewBug
{
    public class MainViewModel : BaseViewModel
    {
        private static int id;

        private ObservableCollection<string> items = new ObservableCollection<string>();
        public ObservableCollection<string> Items
        {
            get => items;
            set => SetProperty(ref items, value);
        }

        // Removing the previous item fixes the graphical artifact.   
        public Command RemoveLastItemCommand => new Command(
            _ => items.RemoveAt(items.Count - 1));

        /// <summary>
        /// Adds random new item.
        /// </summary>
        public Command AddItemCommand => new Command(
            _ => 
            {
                string newItem = $"{id++}_{Guid.NewGuid().ToString()}";
                if (items.Count > 0)
                {
                    // Inserting the item to the front causes the new item to be drawn over the previous item.
                    items.Insert(0, newItem);
                }
                else 
                {
                    items.Add(newItem);
                }
            });
    }
}
